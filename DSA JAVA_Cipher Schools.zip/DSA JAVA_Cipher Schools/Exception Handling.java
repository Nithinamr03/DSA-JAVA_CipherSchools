package com.company;
/*
//Exception Handling..
import java.util.Scanner;
class TestException {
	public static void main(String[] args) {
		int a, b;
		String s = null;
		// String s = "Hello";
		int arr[] = {1, 2, 3, 4, 5};
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter value for a & b: ");
		a = sc.nextInt();
		b = sc.nextInt();

		try {
			System.out.println("Result: " + (a / b));
			System.out.println(s.length());
			System.out.println(arr[8]);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		System.out.print("Our task is over.");
	}
}
*/



/*
//finally block
import java.util.Scanner;
class TestException {
	public static void main(String[] args) {
		int a, b;
		String s = null;
		// String s = "Hello";
		int arr[] = {1, 2, 3, 4, 5};
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter value for a & b: ");
		a = sc.nextInt();
		b = sc.nextInt();

		try {
			System.out.println("Result: " + (a / b));
			System.out.println(s.length());
			System.out.println(arr[8]);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			System.out.println("Some very important codes that must be executed");
		}
		System.out.print("Our task is over.");
	}
}
*/