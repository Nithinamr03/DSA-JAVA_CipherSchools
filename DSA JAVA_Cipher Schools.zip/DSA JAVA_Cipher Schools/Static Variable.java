Static Variable: static int x; //x is static variable
Non-static:  int y; // y is a non-static variable



//Static Variable
package com.company;
import java.util.Scanner;
class Student {
	String name;
	int regno;
	static int sem;

	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter name, reg no & semester in order: ");
		name = sc.nextLine();
		regno = sc.nextInt();
		sem = sc.nextInt();
	}
	void show() {
		System.out.println("Details:");
		System.out.println("Name:" + name);
		System.out.println("Reg. No:" + regno);
		System.out.println("Semester:" + sem);
	}
}

class Database {
	public static void main(String[] args) {
		Student s1 = new Student();
		Student s2 = new Student();

		s1.input();
		s2.input();

		s1.show();
		s2.show();

	}

}