class Test{
	int x; //Data member
	void show() //Method
	{
		System.out.println("Data: " + x);
	}
	public static void main(String[] args) {
		Test ob = new Test(); //Object Creation
		ob.x = 25;
		ob.show();
	}
}
