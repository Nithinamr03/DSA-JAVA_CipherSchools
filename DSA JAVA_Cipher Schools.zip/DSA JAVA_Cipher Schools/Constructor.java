package com.company;
/*
new Test()	-> invokes the constructor
Test ob		-> Reference Variable
*/



/*
class Dummy {
	int a;

	public Dummy() {
		a = 20; // Initialization of data member
	}
	void show() {
		System.out.println("Dummy Class Method " + a);
	}
	public static void main(String[] args) {
		Dummy ob = new Dummy(); //Creates Object
		ob.show();
	}
}
*/



/*
class Test {
	int data;
	public Test() { } //Default Constructor..
	public Test(int val) {  //Parameterized Constructor..
		data = val;
	}

	void show() {
		System.out.println("Data: " + data);
	}
}

class TestDrive {
	public static void main(String[] args) {

		Test ob = new Test();
		ob.show();

		Test obj = new Test(35);
		obj.show();
	}
}*/


/*
class Test {
	int data;
	public Test() { }
	public Test(int data) {
		this.data = data; //this returns reference of current object
	}

	void show() {
		System.out.println("Data: " + data);
	}
}

class TestDrive {
	public static void main(String[] args) {

		Test ob = new Test(35);
		ob.show();
	}
}
*/

//Copy Constructor: It's a parameterized constructor. It copies data of one object to another.



class Test  {
	int x;
	public Test() {
		x = 30;
	}
	public Test(int x) {
		this.x = x;
	}

	public Test(Test ob) {
		x = ob.x;
	}
	void show() {
		System.out.println("Data: " + x);
	}
}

class TestDrive {
	public static void main(String[] args) {
		Test ob1 = new Test();
		Test ob2 = new Test(35);
		Test ob3 = new Test(45);
		ob1.show();
		ob2.show();
		ob3.show();
		Test ob4 = ob3; //Shallow Copy..
		ob4.x = 55;
		ob4.show();
		ob3.show();
		Test ob5 = new Test(ob3); //Deep Copy..
		ob5.x=65;
		ob5.show();
		ob3.show();
	}

}