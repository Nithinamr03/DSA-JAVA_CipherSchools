// Setters & Getters

class Demo {
	private int a;
	//protected int b;
	//public int c;
	//default
	//int d;

	//setter
	void setA(int val) {
		a = val;
	}

	//getter
	int getA() {
		return a;
	}
}
class DemoDriver {
	public static void main(String[] args) {
		Demo ob = new Demo();
		ob.setA(20);
		System.out.println("Data: " + ob.getA());
	}

}
