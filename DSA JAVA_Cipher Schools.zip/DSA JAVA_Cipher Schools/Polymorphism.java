package com.company;
/*
// Method Overloading
class Demo {
	int add(int a, int b, int c) {
		return a + b + c;
	}
	int add(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		Demo ob = new Demo();
		int res = ob.add(25, 35);
		// int res = ob.add(25, 35, 40);
		System.out.println("Sum: " + res);
	}
}
*/

/*
// Method Overriding
class Vehicle {
	void accl() {
		System.out.println("Accelerating at 100kmph");
	}

	void brake() {
		System.out.println("Braking...");
	}
}

class Car extends Vehicle {
	void accl() {
		System.out.println("Accelerating at 120kmph");
	}
	public static void main(String[] args) {
		Car ob = new Car();
		ob.accl();
		ob.brake();
	}
}
*/