package com.company;
/*
//Single Inheritance..

class Animal {
	void run() {
		System.out.println("Running");
	}
}

class Lion extends Animal{
	void roar() {
		System.out.println("Roaring");
	}

	public static void main(String[] args) {
		Lion l = new Lion();
		Animal a = new Animal();

		l.roar();
		l.run();

		a.run();
		// a.roar(); // This will give an error..Because parent object can't access Child members..
		
	}

}
*/

/*
// Multilevel
class Animal {
	void run() {
		System.out.println("Running");
	}
}

class Lion extends Animal{
	void roar() {
		System.out.println("Roaring");
	}
}
class Cub extends Lion {
	void play() {
		System.out.println("Playing");
	}

	public static void main(String[] args) {
		Cub c = new Cub();

		c.play();
		c.roar();
		c.run();
	}

}
*/

/*
// Hierarchical Inheritance
class Animal {
	void run() {
		System.out.println("Running");
	}
}

class Lion extends Animal{
	void roar() {
		System.out.println("Roaring");
	}
}

class Dog extends Animal {
	void bark() {
		System.out.println("Barking");
	}
}
class Drive {
	public static void main(String[] args) {
		Lion l = new Lion();
		Dog d = new Dog();
		l.roar();
        l.run();
		d.bark();
		d.run();

		// l.bark(); // Error
		// d.roar(); // Error
	}

}
*/


/*
// Multiple Inheritance
class A {
	void show() {

	}
}

class B {
	void show() {

	}
}

class C extends A, B {
	void fun() {

	}
	public static void main(String[] args) {
		C ob = new C();
		ob.show(); // Ambiguity in method invocation..
	}

}
*/


/*
//super() invokes parent Constructor..
//super keyword invokes parent method..
class Parent{
	public Parent(){
		System.out.println("Parent Class Constructor..");
	}
	void showParent(){
		System.out.println("Parent Class Method..");
	}
}

class Child extends Parent{
	public Child(){
		//super();
		System.out.println("Child Class Constructor..");
	}
	void showChild(){
		super.showParent();
		System.out.println("Child Class Method..");
	}
}
class Driver {
	public static void main(String[] args) {
		Child ch = new Child();
		ch.showChild();
	}
}
/*