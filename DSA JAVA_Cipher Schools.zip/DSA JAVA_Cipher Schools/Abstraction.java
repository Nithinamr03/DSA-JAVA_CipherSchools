package com.company;
/*
Abstraction can be implemented using:
a) Abstract class (> 0% & <= 100%)
b) Interface (100% Abstraction)

//Implementation of Abstract Class
abstract class Music {
	abstract void play();
	
	void bass() {
		System.out.println("Extra Bass...");
	}
}

class MusicDevice extends Music {
	void play() {
		System.out.println("Playing Music...");
	}
}

class Player {
	public static void main(String[] args) {
		MusicDevice md = new MusicDevice();
		md.play();
		md.bass();
	}
}
*/



/*
// Implementation of Interface:
interface Music {
	void play(); //abstract public void play();
	void bass();
}

class MusicDevice implements Music {
	public void play() {
		System.out.println("Playing Music...");
	}

	public void bass() {
		System.out.println("Extra Bass...");
	}
}
class Player {
	public static void main(String[] args) {
		MusicDevice md = new MusicDevice();
		md.play();
		md.bass();
	}
}
*/