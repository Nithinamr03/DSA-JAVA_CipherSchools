import java.util.Scanner;
import java.util.Arrays;
class ArrayRotation {
	static Scanner sc = new Scanner(System.in);
	static void input(int arr[]) {
		System.out.print("Enter the array elements: ");
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
	}
	static void display(int arr[]) {
		System.out.print("Array elements are: ");
		for(int i : arr) {
			System.out.print(i + " ");
		}
	}

	static void printRotatedArray(int arr[], int k) {
		int n = arr.length;
		int r = k % n;

		for(int i = r; i < n; i++) {
			System.out.print(arr[i] + " ");
		}
		for(int i = 0; i < r; i++) {
			System.out.print(arr[i] + " ");
		}
	}
	
	
	public static void main(String[] args) {
		
		int array[], n, k;

		System.out.print("Enter no of elements: ");
		n = sc.nextInt();

		array = new int[n];
		input(array);
		display(array);

		System.out.print("\nEnter no of left rotations: ");
		k = sc.nextInt();
		printRotatedArray(array, k);
		
	}

}